package com.hcl.gl.pojo;

//-----------------------------PRODUCT POJO---------------------------
public class Product {

	//-------------Initialization--------------------------------
	private int productId;
	private String productName;
	private String productText;
	private String productDescription;
	private String productHighlights;
	private String productCategory;
	private int availableQuantity;
	private int buyingPrice;
	private float sellingPrice;
	private float profitAmount;


	//-------------Getters & Setters----------------------------------
	public String getProductText() {
		return productText;
	}
	public void setProductText(String productText) {
		this.productText = productText;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getProductHighlights() {
		return productHighlights;
	}
	public void setProductHighlights(String productHighlights) {
		this.productHighlights = productHighlights;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getAvailableQuantity() {
		return availableQuantity;
	}
	public void setAvailableQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;
	}
	public int getBuyingPrice() {
		return buyingPrice;
	}
	public void setBuyingPrice(int buyingPrice) {
		this.buyingPrice = buyingPrice;
	}
	public float getSellingPrice() {
		return sellingPrice;
	}

	public void setSellingPrice(int buyingPrice) {
		this.sellingPrice = (float) ((buyingPrice*0.5)+buyingPrice);
	}


	public float getProfitAmount() {
		return profitAmount;
	}

	public void setProfitAmount(int buyingPrice) {
		this.profitAmount = (float)((buyingPrice*0.5)+buyingPrice) - buyingPrice ;
	}
	//-----------------------END OF GETTERS AND SETTERS------------------------------
	//---------------------TOSTRING FUNCTION------------------------
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productText=" + productText
				+ ", productDescription=" + productDescription + ", productHighlights=" + productHighlights
				+ ", productCategory=" + productCategory + ", availableQuantity=" + availableQuantity
				+ ", sellingPrice=" + sellingPrice + "]";
	}

	//---------------CONSTRUCTORS USING FIELDS------------------------
	public Product(int productId, String productName, String productText, String productDescription,
			String productHighlights, String productCategory, int availableQuantity, int buyingPrice,
			float sellingPrice, float profitAmount) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productText = productText;
		this.productDescription = productDescription;
		this.productHighlights = productHighlights;
		this.productCategory = productCategory;
		this.availableQuantity = availableQuantity;
		this.buyingPrice = buyingPrice;
		this.sellingPrice = sellingPrice;
		this.profitAmount = profitAmount;
	}

	// ---------------CONSTRUCTORS USING SUPERCLASS---------------
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}









}
