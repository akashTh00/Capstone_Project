package com.hcl.gl.pojo;
//-------------------------ADMIN POJO----------------------------------------------
public class Admin
{	
	//----------------------user credential 
	private String adminName = "princy";
	private String emailId = "princy@mail.com";
	private String password = "princy";

	// Getters to get the user Info.
	public String getAdminName() {
		return adminName;
	}

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}


}
