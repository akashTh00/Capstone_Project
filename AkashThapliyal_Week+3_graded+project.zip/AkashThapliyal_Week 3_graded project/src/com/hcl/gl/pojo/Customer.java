package com.hcl.gl.pojo;

//------------------------CUSTOMER POJO------------------------------------------
public class Customer
{
	//-------------------------------INITIALIZATION--------------------------------
	private int customerId;
	private String customerName;
	private String customerEmailId;
	private int customerPin;
	private String customerPassword;
	private int supercoins;
	
	
	//-----------------------Getters and Setters----------------------------------------
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerEmailId() {
		return customerEmailId;
	}
	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}
	public int getCustomerPin()
	{
		return customerPin;
	}
	public void setCustomerPin(int customerPin) {
		this.customerPin = customerPin;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public int getSupercoins() {
		return supercoins;
	}
	public void setSupercoins(int supercoins) {
		this.supercoins = supercoins;
	}
//-------------------------------END OF GETTERS AND SETTERS--------------------------------------
}
