package com.hcl.gl.Exception;

@SuppressWarnings("serial")
public class NegativeExcepAdmin extends RuntimeException {
	
	public NegativeExcepAdmin(String string) {
		System.out.println("EXITED..");
	}

}
