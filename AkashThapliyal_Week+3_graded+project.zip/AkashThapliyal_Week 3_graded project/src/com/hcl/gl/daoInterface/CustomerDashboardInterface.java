package com.hcl.gl.daoInterface;

public interface CustomerDashboardInterface {
	public void viewAllProduct();
	public void account();
	public void cart();
}
