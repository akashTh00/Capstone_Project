package com.hcl.gl.daoInterface;

public interface CustomerDaoInterface {

	public void register();
	public void login();

}
