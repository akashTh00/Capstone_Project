package com.hcl.gl.daoInterface;

public interface StoreInformation_Interface {
	
	public void listProduct();
	public void searchById();
	public void viewByCategory();
	public void tSpendAmount();
	public void viewAllProducts();
	
	
}
