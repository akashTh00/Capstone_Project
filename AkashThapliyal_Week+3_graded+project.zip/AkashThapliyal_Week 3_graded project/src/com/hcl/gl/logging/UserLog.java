package com.hcl.gl.logging;


import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
//------------------------------------USER LOGs CLASS------------------------------------------
public class UserLog {
	public static void writeLog(String msg)
	{
		Logger logger = Logger.getLogger("Logging");
		
		try
		{
			FileHandler fh = new FileHandler("C:\\Users\\akash.thapliyal\\OneDrive - HCL Technologies Ltd\\Documents\\eclipse-oxy\\eclipse\\AkashThapliyal_Week 2_graded project\\src\\com\\hcl\\gl\\logging\\tasklogs.txt");
			logger.addHandler(fh);
			
			LocalDateTime date = LocalDateTime.now();
			
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("mm/dd/yyyy HH:mm:ss");	
			String logDate = "DateTimeStamp : " + date.format(formatter);
			String result = logDate.concat(" " + msg + "\n");
			SimpleFormatter sm = new SimpleFormatter();
			fh.setFormatter(sm);
			logger.info(result);
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
}

