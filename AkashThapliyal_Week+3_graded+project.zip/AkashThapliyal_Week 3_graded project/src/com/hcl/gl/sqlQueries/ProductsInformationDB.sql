create database ProductsInformationDB;
use ProductsInformationDB;

create table products(productId int not null unique PRIMARY KEY,
					  productName varchar(40) not null,
                      productText varchar(60) not null,
                      productDescription varchar(80) not null,
                      productHighlights varchar (120) not null,
                      productCategory varchar(40) not null,
                      availableQuantity int not null,
                      buyingPrice int not null,
                      sellingPrice float not null);
                      
create table customerCart(customerId int not null,
				  productId int not null,
                  status varchar(20) not null);
   drop table customerCart;               

select * from products;
desc products;
drop table products;
          drop table cart2;            
select availableQuantity,buyingPrice from products;
select count(*) from products;