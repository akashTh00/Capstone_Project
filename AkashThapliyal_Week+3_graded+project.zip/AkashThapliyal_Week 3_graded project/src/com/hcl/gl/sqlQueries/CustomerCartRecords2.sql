create database CustomerCartRecords2;
use customerCartRecords2;

create table cart2(customerId int not null,
				  productId int not null,
                  status varchar(20) not null);
   drop table cart2;               
select * from cart2;

insert into cart values(101,101,1);
desc cart2;

drop table cart2;