package com.hcl.gl.jdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//--------------------------------singleton design pattern---------------------------
public class CustomerRegistration {
	private static CustomerRegistration single_connection=null;
	public static Connection con;

	private CustomerRegistration()
	{
		try {
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/CustomerRegistration", "root", "Aa2000@com");
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//GETTERS AND SETTERS
	public static CustomerRegistration getConnection() throws SQLException
	{
		if(single_connection==null)
		{
			single_connection = new CustomerRegistration();
		}
		return single_connection;
	}
}
