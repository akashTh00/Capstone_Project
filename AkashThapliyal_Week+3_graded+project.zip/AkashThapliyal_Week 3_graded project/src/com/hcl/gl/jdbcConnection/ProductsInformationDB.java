package com.hcl.gl.jdbcConnection;
import java.sql.*;

public class ProductsInformationDB 
{
	//--------------------------------singleton design pattern---------------------------
	private static ProductsInformationDB single_connection=null;
	public static Connection con;

	private ProductsInformationDB()
	{
		try {
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ProductsInformationDB", "root", "Aa2000@com");
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//GETTERS AND SETTERS
	public static ProductsInformationDB getConnection() throws SQLException
	{
		if(single_connection==null)
		{
			single_connection = new ProductsInformationDB();
		}
		return single_connection;
	}
}
