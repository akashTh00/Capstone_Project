package com.hcl.gl.jdbcConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//--------------------------------singleton design pattern---------------------------
public class CustomerCartRecords2 {
	private static CustomerCartRecords2 single_connection=null;
	public static Connection con2;

	private CustomerCartRecords2()
	{
		try {
			con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/CustomerCartRecords2", "root", "Aa2000@com");
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//GETTERS AND SETTERS
	public static CustomerCartRecords2 getConnection() throws SQLException
	{
		if(single_connection==null)
		{
			single_connection = new CustomerCartRecords2();
		}
		return single_connection;
	}
}
