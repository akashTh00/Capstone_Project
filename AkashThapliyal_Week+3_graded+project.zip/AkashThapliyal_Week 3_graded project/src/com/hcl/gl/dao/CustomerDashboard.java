package com.hcl.gl.dao;

import java.sql.PreparedStatement;
import java.sql.*;
import java.util.*;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.hcl.gl.daoInterface.CustomerDashboardInterface;
import com.hcl.gl.jdbcConnection.CustomerCartRecords2;
import com.hcl.gl.jdbcConnection.CustomerRegistration;
import com.hcl.gl.jdbcConnection.ProductsInformationDB;
import com.hcl.gl.pojo.Product;

public class CustomerDashboard implements CustomerDashboardInterface {

	//---------------------INITIALIZATION---------------------------------
	ProductsInformationDB conn;
	CustomerRegistration registConn;
	CustomerCartRecords2 cartConn;
	PreparedStatement pst;
	PreparedStatement psCart;
	PreparedStatement ps;
	Product product = new Product();
	Scanner sc = new Scanner(System.in);
	String loginMail;
	public int custId;
	int sum = 0;
	public int count=0;
	int productExist=0;
	int statusOfOrder=0;
	int customId;
	int superCoins;
	int discount = 0;
	int makeStatus=1;

	//------------------------CONSTRUCTORS------------------------------
	public CustomerDashboard()
	{

	}
	public CustomerDashboard(String loginMail) {
		this.loginMail = loginMail;
	}

	// -------------------------START OF VIEW ALL PRODUCT FUNCTION------------------------------------
	//-----------------ViewAllProducts Function-----------------------------
	@Override
	public void viewAllProduct() {
		System.out.println("----------------------------------");
		System.out.println("VIEWING..");
		System.out.println("----------------------------------");
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products ORDER BY sellingPrice ASC");
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				System.out.println("Product [productId=" + rs.getInt(1) + ", productName= " + rs.getString(2) + ", productText= \'" + rs.getString(3)
				+ "\', productDescription= \'" + rs.getString(4) + "\', productCategory= \'" + rs.getString(6) + "\', sellingPrice= $" + rs.getFloat(8) + "]\n");
			}
			System.out.println("----------------------------------");
			System.out.println("1. See the Product Details");
			System.out.println("2. back");
			System.out.println("----------------------------------");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("----------------------------------");
				System.out.println("ENTER PRODUCT ID");
				System.out.println("----------------------------------");
				int pId = sc.nextInt();
				System.out.println("----------------------------------");
				pst = ProductsInformationDB.con.prepareStatement("Select * from products where productId=?");
				pst.setInt(1, pId);
				ResultSet result = pst.executeQuery();
				while(result.next())
				{
					System.out.println("\n--- -- --- " + result.getString(2) + " (" + result.getString(3)
					+ ") --- -- ---\n --- Description : " + result.getString(4) + " ---\n --- Highlights : " + result.getString(5)
					+ " ---\n --- Category : " + result.getString(6) + " --- \n --- Price : $" + result.getString(9) + " ---\n");
					System.out.println("----------------------------------");
					System.out.println("1. Add To Cart");
					System.out.println("2. Back");
					System.out.println("----------------------------------");
					int select = sc.nextInt();
					System.out.println("----------------------------------");
					switch(select)
					{
					case 1:
						registConn = CustomerRegistration.getConnection();
						pst = CustomerRegistration.con.prepareStatement("select customerId from Registration where customerEmailId=?");
						pst.setString(1,loginMail);
						ResultSet res = pst.executeQuery();
						while(res.next())
						{
							int custIdRecord = res.getInt(1);
							this.custId = custIdRecord;

						} 

						addToCart(pId, custId);
						System.out.println("----------------------------------");
						break;
					case 2:
						break;
					default:
						System.out.println("invalid input");
						break;
					}
				}
				break;

			case 2:
				break;
			default:
				System.out.println("invalid input");
				break;
			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}

	public void addToCart(int pId, int custId) {
		int customerId = custId;
		int prodId = pId;
		String status = "pending";
		try
		{
			cartConn = CustomerCartRecords2.getConnection();
			pst = CustomerCartRecords2.con2.prepareStatement("insert into cart2 values(?,?,?,?)");
			pst.setInt(1, customerId);
			pst.setInt(2, prodId);
			pst.setString(3, status);
			//------------LocalDateTime---------------
			LocalDateTime date = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
			String logDate = date.format(formatter);
			//------------------------------------------
			pst.setString(4, logDate);
			int st = pst.executeUpdate();
			if(st == 1)
			{
				System.out.println("Item added to cart");
			}
			else
			{
				System.out.println("problem while adding item to cart");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}

	}

	//------------------------cart function---------------------------------
	public void cart()
	{
		System.out.println("----------------------------------------");
		System.out.println("----------------MY CART-----------------");
		System.out.println("----------------------------------------");
		try
		{
			pst = CustomerRegistration.con.prepareStatement("select customerId from Registration where customerEmailId=?");
			pst.setString(1,loginMail);
			ResultSet res = pst.executeQuery();

			while(res.next())
			{
				int custIdRecord = res.getInt(1);
				this.custId = custIdRecord;

			} 
			int resultStatus = myCart(custId);
			if(resultStatus == 1)
			{
				System.out.println("1. Remove From Cart");
				System.out.println("2. Place Order");
				System.out.println("0. Back");
				System.out.println("--------------------------------------");
				int choice;
				choice = sc.nextInt();
				switch(choice)
				{
				case 1:
					System.out.println("--------------------------------------");
					System.out.println("Enter ProductId");
					System.out.println("--------------------------------------");
					int inputPdtId = sc.nextInt();
					pst = CustomerCartRecords2.con2.prepareStatement("delete from cart2 where productId=? AND status=?");
					pst.setInt(1, inputPdtId);
					pst.setString(2, "pending");
					int result = pst.executeUpdate();

					if(result==1)
					{
						System.out.println("Successfully Removed.");
						System.out.println("--------------------------------------");
					}

					break;
				case 2:
					System.out.println("--------------------------------------");
					System.out.println("Redeam the supercoin(100 coins=$5)");
					System.out.println("1. YES");
					System.out.println("2. NO");
					System.out.println("0. Back");
					System.out.println("--------------------------------------");
					int select = sc.nextInt();
					switch(select)
					{
					case 1:
						System.out.println("---------------------------------------");
						System.out.println("Price Details");
						ResultSet reslt2 = pst.executeQuery();
						while(reslt2.next())
						{
							int pdtId3 = reslt2.getInt(1);
							orderCart(pdtId3);
						}
						pst = CustomerRegistration.con.prepareStatement("select supercoins from Registration where customerId=?");
						pst.setInt(1,custId);
						ResultSet mark = pst.executeQuery();
						while(mark.next())
						{
							superCoins = mark.getInt(1);
						}
						if(superCoins==100)
						{
							discount=5;
						}
						else
						{
							discount = 0;
						}
						if(discount == 0)
						{
							System.out.println("----You have already redeamed the Supercoins----");
						}

						System.out.println("---------------------------------------");
						System.out.println("Price ("+count+" items)                  " + "$" + sum); 

						System.out.println("Discount                         " + "-$"+discount);		
						System.out.println("Delivery Charges                 " + "Free\n");
						System.out.println("---------------------------------------");
						System.out.println("Total Amount                     " + "$" + (sum-discount));
						System.out.println("---------------------------------------");
						sum = 0;
						count = 0;
						System.out.println("To Continue");
						System.out.println("1. Yes");
						System.out.println("2. No");
						System.out.println("--------------------------------------");
						int sel = sc.nextInt();
						switch(sel)
						{
						case 1:
							cartConn = CustomerCartRecords2.getConnection();
							pst = CustomerCartRecords2.con2.prepareStatement("select productId from cart2 where customerId=? And status=?");
							pst.setInt(1, customId);
							pst.setString(2, "pending");
							ResultSet reslt5 = pst.executeQuery();
							while(reslt5.next())
							{
								int pdtId1 = reslt5.getInt(1);

								//-------------
								if(makeStatus==1)
								{
									conn = ProductsInformationDB.getConnection();
									PreparedStatement pstt = ProductsInformationDB.con.prepareStatement("select availableQuantity from products where productId=?");
									pstt.setInt(1, pdtId1);
									ResultSet rs = pstt.executeQuery();
									while(rs.next())
									{
										int aq = rs.getInt(1);
										if(aq > 0)
										{
											conn = ProductsInformationDB.getConnection();
											PreparedStatement pss = ProductsInformationDB.con.prepareStatement("update products set availableQuantity=? where productId=?");
											pss.setInt(1, aq-1);
											pss.setInt(2, pdtId1);
											int resultSet = pss.executeUpdate();
											if(resultSet==1)
											{
												updateCart(pdtId1);
												updateCustomer(customId);
											}
										}
										else {
											System.out.println("FEW OF THE ITEMS IN YOUR CART ARE OUT OF STOCK RIGHT NOW!");
											this.makeStatus=0;
										}

									}
								}
							}
							this.makeStatus = 1;
							System.out.println("--------------------------------------");
							break;
						case 2:
							break;
						default:
							System.out.println("invalid input");
							break;
						}
						break;
					case 2:
						System.out.println("---------------------------------------");
						System.out.println("Price Details");
						ResultSet reslt3 = pst.executeQuery();
						while(reslt3.next())
						{
							int pdtId2 = reslt3.getInt(1);
							orderCart(pdtId2);
						}
						System.out.println("---------------------------------------");
						System.out.println("Price ("+count+" items)                  " + "$" + sum); 
						System.out.println("Discount                         " + "0$");
						System.out.println("Delivery Charges                 " + "Free\n");
						System.out.println("---------------------------------------");
						System.out.println("Total Amount                     " + "$" + (sum));
						System.out.println("---------------------------------------");
						sum = 0;
						count = 0;
						System.out.println("To Continue");
						System.out.println("1. Yes");
						System.out.println("2. No");
						System.out.println("--------------------------------------");
						int selct = sc.nextInt();
						switch(selct)
						{
						case 1:
							cartConn = CustomerCartRecords2.getConnection();
							pst = CustomerCartRecords2.con2.prepareStatement("select productId from cart2 where customerId=? And status=?");
							pst.setInt(1, customId);
							pst.setString(2, "pending");
							ResultSet reslt5 = pst.executeQuery();
							while(reslt5.next())
							{
								int pdtId1 = reslt5.getInt(1);

								//-----
								//-------------
								if(makeStatus==1)
								{
									conn = ProductsInformationDB.getConnection();
									PreparedStatement pstt = ProductsInformationDB.con.prepareStatement("select availableQuantity from products where productId=?");
									pstt.setInt(1, pdtId1);
									ResultSet rs = pstt.executeQuery();
									while(rs.next())
									{
										int aq = rs.getInt(1);
										if(aq > 0)
										{

											conn = ProductsInformationDB.getConnection();
											PreparedStatement pss = ProductsInformationDB.con.prepareStatement("update products set availableQuantity=? where productId=?");
											pss.setInt(1, aq-1);
											pss.setInt(2, pdtId1);
											int resultSet = pss.executeUpdate();
											if(resultSet==1)
											{
												updateCart(pdtId1);
											}
										}
										else {
											System.out.println("FEW OF THE ITEMS IN YOUR CART ARE OUT OF STOCK RIGHT NOW!");
											this.makeStatus=0;
										}
									}
								}
							} 
							this.makeStatus=1;
							System.out.println("--------------------------------------");
							break;
						case 2:
							break;
						default:
							System.out.println("invalid input");
							break;
						}
						break;
					case 0:
						break;
					default:
						System.out.println("invalid input");
						break;
					}

					break;
				case 0:
					break;
				default:
					System.out.println("invalid input");
					break;
				}
				productExist=0;
			}
			else
			{
				System.out.println("Your Cart is empty!");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}

//-----------------------my cart function------------------------------
	private int myCart(int custId)
	{
		this.customId = custId;
		try
		{
			cartConn = CustomerCartRecords2.getConnection();
			pst = CustomerCartRecords2.con2.prepareStatement("select productId from cart2 where customerId=? And status=?");
			pst.setInt(1, customId);
			pst.setString(2, "pending");
			ResultSet reslt = pst.executeQuery();
			while(reslt.next())
			{
				int pdtId = reslt.getInt(1);
				//--------calling showCartProd function----------------------------
				showCartProd(pdtId);
				this.productExist = 1;

			} 


		}
		catch(SQLException e)
		{

		}
		return productExist;
	}
	//-------------------------update customer-------------------
	private void updateCustomer(int custId)
	{
		int customId = custId;
		try
		{
			registConn = CustomerRegistration.getConnection();
			pst = CustomerRegistration.con.prepareStatement("update Registration set supercoins=? where customerId=? AND supercoins=?");
			pst.setInt(1, 0);
			pst.setInt(2, customId);
			pst.setInt(3, 100);
			int rest = pst.executeUpdate();
			if(rest==1)
			{
				//				System.out.println("customer updated");
			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//------------------------update cart------------------------------
	private void updateCart(int pdtId)
	{
		int prodId = pdtId;
		try
		{
			cartConn = CustomerCartRecords2.getConnection();
			pst = CustomerCartRecords2.con2.prepareStatement("update cart2 set status=?,DateTime=? where productId=? AND status=?");
			pst.setString(1, "delivered");
			//------------LocalDateTime---------------
			LocalDateTime date = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
			String logDate = date.format(formatter);
			//-----------------------------
			pst.setString(2, logDate);
			pst.setInt(3, prodId);
			pst.setString(4, "pending");
			int rest = pst.executeUpdate();
			if(rest==1)
			{
				System.out.println("order booked, will be delivered within 4 working days");
			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//--------------------orderCart Function---------------------
	private void orderCart(int pdtId)
	{
		int orderProdId = pdtId;
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select sum(sellingPrice), count(*) from products where productId=?");
			pst.setInt(1, orderProdId);
			ResultSet rs = pst.executeQuery();

			while(rs.next())
			{
				sum += rs.getInt(1);
				this.count++;

			}

		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
//--------------------showCartProd function implementation--------------
	private void showCartProd(int pdtId) throws SQLException
	{
		int prodId = pdtId;

		conn = ProductsInformationDB.getConnection();
		PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products where productId=?");
		pst.setInt(1, prodId);
		ResultSet rs = pst.executeQuery();

		while(rs.next())
		{
			int availableQ = rs.getInt(7);
			if(availableQ<1)
			{
				System.out.println("\n--- -- --- OUT OF STOCK--- -- --- ");
			}
			System.out.println("--- -- --- " + rs.getString(2) + " (" + rs.getString(3)
			+ ") ( ID : "+rs.getInt(1)+") --- -- ---\n --- Description : " + rs.getString(4) + " ---\n --- Highlights : " + rs.getString(5)
			+ " ---\n --- Category : " + rs.getString(6) + " --- \n --- Price : $" + rs.getString(9) + " ---\n");
		}


	}

	// -------------------------END OF VIEW ALL PRODUCT FUNCTION------------------------------------

	//-----------------------ACCOUNT----------------------------------
	public void account()
	{
		System.out.println("--------------MY ACCOUNT--------------");
		System.out.println("1. Profile");
		System.out.println("2. Orders");
		System.out.println("0. Back");
		System.out.println("--------------------------------------");
		int scan = sc.nextInt();
		switch(scan)
		{
		case 1:
			profile();
			break;
		case 2:
			System.out.println("-------------DELIVERED ITEMS-------------");
			int checkOrder = orders();

			if(checkOrder==1)
			{

			}
			else
			{
				System.out.println("No items yet DELIVERED!");
			}
			System.out.println("--------------------------------------");
			System.out.println("Press any key to go back");
			String scanning = sc.next();
			switch(scanning)
			{
			case "dd":
				break;
			default:
				break;
			}
			break;
		case 0:
			break;
		default:
			System.out.println("invalid input");
			break;
		}

	}
	//-------------orders------------------------
	private int orders()
	{
		try
		{
			registConn = CustomerRegistration.getConnection();
			pst = CustomerRegistration.con.prepareStatement("select customerId from Registration where customerEmailId=?");
			pst.setString(1,loginMail);
			ResultSet res = pst.executeQuery();
			while(res.next())
			{
				int custIdRecord = res.getInt(1);
				this.custId = custIdRecord;

			} 
			//----------------
			cartConn = CustomerCartRecords2.getConnection();
			pst = CustomerCartRecords2.con2.prepareStatement("select productId,DateTime from cart2 where status=? AND customerId=?");
			pst.setString(1, "delivered");
			pst.setInt(2, custId);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{	
				int pductId = rs.getInt(1);
				String dateTime = rs.getString(2);
				conn = ProductsInformationDB.getConnection();
				PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products where productId=?");
				pst.setInt(1, pductId);
				ResultSet mark = pst.executeQuery();
				while(mark.next())
				{
		
					System.out.println("\n--- -- --- " + mark.getString(2) + " (" + mark.getString(3)
					+ ") (Product Id: " + mark.getInt(1) + ")--- -- ---\n --- Description : " + mark.getString(4) + " ---\n --- Category : " + mark.getString(6) + " --- \n --- Price : $" + mark.getString(9) + " ---\n"+" --- Delivered On : " + dateTime + " ---\n");
				}
				this.statusOfOrder = 1;
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return statusOfOrder;
	}

	//-------------profile------------------------
	private void profile()
	{
		try
		{
			registConn = CustomerRegistration.getConnection();
			pst = CustomerRegistration.con.prepareStatement("select * from Registration where customerEmailId=?");
			pst.setString(1,loginMail);
			ResultSet result = pst.executeQuery();
			while(result.next())
			{

				System.out.println("-------------MY PROFILE-------------");
				System.out.println("\n--- -- --- Name : " + result.getString(2) + " (Unique Id: " + result.getInt(1)
				+ ") --- -- ---\n--- -- --- ADDRESS PINCODE : " + result.getInt(5) + "--- -- --- \n--- -- --- Supercoins : " + result.getInt(6)
				+ "--- -- --- \n--- -- --- Email ID : " + result.getString(3)+ "--- -- --- \n");
				System.out.println("--------------------------------------");
				System.out.println("Press any key to go back");
				String scan = sc.next();
				switch(scan)
				{
				case "dd":
					break;
				default:
					break;
				}
			} 
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
}
