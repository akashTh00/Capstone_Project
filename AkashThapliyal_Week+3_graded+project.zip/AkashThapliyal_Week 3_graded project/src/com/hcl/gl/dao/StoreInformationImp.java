package com.hcl.gl.dao;

import com.hcl.gl.daoInterface.StoreInformation_Interface;
import com.hcl.gl.jdbcConnection.CustomerRegistration;
import com.hcl.gl.jdbcConnection.ProductsInformationDB;
import com.hcl.gl.logging.UserLog;
import com.hcl.gl.pojo.Product;


import java.util.*;
import java.sql.*;
public class StoreInformationImp implements StoreInformation_Interface {

	Scanner sc = new Scanner(System.in);

	//--------------INITIALIZATION------------------------
	Product product;
	int productId;
	int tSpendCategory=0;
	int tSpendAll=0;
	ProductsInformationDB conn;
	CustomerRegistration registConn;
	public int custId;
	String loginMail;
	int pointer=0;

	//--------------storeInformation constructor------------
	StoreInformationImp()
	{

	}
	StoreInformationImp(String loginMail)
	{
		this.loginMail = loginMail;
	}


	//------------listing the products into the store---------------------
	@Override
	public void listProduct()
	{
		String pdtName, pdtText, pdtDescription, pdtHighLight, pdtCategory;
		int avlbQuantity, buyPrice;

		Random random = new Random();
		try
		{
			conn = ProductsInformationDB.getConnection();
			product = new Product();

			// --------------------USER INPUT---------------------------------

			System.out.println("Enter Product Name");
			pdtName = sc.next();
			System.out.println("Enter Product Text");
			sc.nextLine();
			pdtText = sc.nextLine();
			System.out.println("Enter Product Description");
			pdtDescription = sc.nextLine();
			System.out.println("Enter Product HighLights");
			pdtHighLight = sc.nextLine();
			System.out.println("Enter Product Category");
			pdtCategory = sc.next();
			System.out.println("Enter Product Available Quantity");
			avlbQuantity = sc.nextInt();
			System.out.println("Enter Product Buying Price");
			buyPrice = sc.nextInt();

			productId = random.nextInt(99999);
			product.setProductId(productId);
			product.setProductName(pdtName);
			product.setProductText(pdtText);
			product.setProductDescription(pdtDescription);
			product.setProductHighlights(pdtHighLight);
			product.setProductCategory(pdtCategory);
			product.setAvailableQuantity(avlbQuantity);
			product.setBuyingPrice(buyPrice);
			product.setSellingPrice(buyPrice);
			product.setProfitAmount(buyPrice);


			// ------------------------DATABASE------------------------------------
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("insert into products values(?,?,?,?,?,?,?,?,?)");
			pst.setInt(1, product.getProductId());
			pst.setString(2, product.getProductName());
			pst.setString(3, product.getProductText());
			pst.setString(4, product.getProductDescription());
			pst.setString(5, product.getProductHighlights());
			pst.setString(6, product.getProductCategory());
			pst.setInt(7, product.getAvailableQuantity());
			pst.setInt(8, product.getBuyingPrice());
			pst.setFloat(9, product.getSellingPrice());

			int rs = pst.executeUpdate();
			if(rs == 1)
			{
				System.out.println("--------------------------------------");
				System.out.println("Product Listed Successfully");
				System.out.println("--------------------------------------");
			}
			else
			{
				System.out.println("--------------------------------------");
				System.out.println("Error while listing!");
				System.out.println("--------------------------------------");
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

		// ------------------LOGGER---------------------------
		UserLog.writeLog(product.getProductName() + " listed successfully");
		//----------------------------------------------------
	}

	//-----------------------searching products by ID-----------------------------------
	@Override
	public void searchById() {
		int pId;

		System.out.println("ENTER PRODUCT ID");
		pId = sc.nextInt();
		System.out.println("--------------------------------------");
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products where productId=?");
			pst.setInt(1, pId);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				System.out.println("\nPRODUCT\n{\nID: " + rs.getInt(1)+"\nNAME: "+ rs.getString(2)+"\nTEXT: "+rs.getString(3)+"\nDESCRIPTION: "+rs.getString(4)+"\nHIGHLIGHTS: "+rs.getString(5)+"\nCATEGORY: "+rs.getString(6)+"\nAVAILBALE QUANITY: "+rs.getInt(7)+"\nBUYING PRICE: "+rs.getInt(8)+"\nSELLING PRICE: "+rs.getFloat(9)+"\n}");
				System.out.println("--------------------------------------");
				System.out.println("Search successfull.");
				System.out.println("--------------------------------------");
				System.out.println("Press any key to go back");
				String scan = sc.next();
				switch(scan)
				{
				case "dd":
					break;
				default:
					break;
				}
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}


	}


	//-------------------------viewing products by category------------------------------
	@Override
	public void viewByCategory() {
		System.out.println("Enter Category?");
		String category = sc.next();
		System.out.println("--------------------------------------");
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products where productCategory=?");
			pst.setString(1, category);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				System.out.println("Product [productId=" + rs.getInt(1) + ", productName= " + rs.getString(2) + ", productText= \'" + rs.getString(3)
				+ "\', productDescription= \'" + rs.getString(4) + "\', productCategory= \'" + rs.getString(6) + "\', sellingPrice= $" + rs.getFloat(8) + "]\n");
			}
			System.out.println("--------------------------------------");
			System.out.println("Press any key to go back");
			String scan = sc.next();
			switch(scan)
			{
			case "dd":
				break;
			default:
				break;
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}

	}

	//------------------------VIEW BY CATEGORY FOR CUSTOMER-------------------------
	public void viewByCategoryForCustomer() {
		System.out.println("----------------------------------");
		System.out.println("Enter Category?");
		System.out.println("----------------------------------");
		String category = sc.next();
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products where productCategory=? ORDER BY sellingPrice ASC");
			pst.setString(1, category);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				System.out.println("Product [productId=" + rs.getInt(1) + ", productName= " + rs.getString(2) + ", productText= \'" + rs.getString(3)
				+ "\', productDescription= \'" + rs.getString(4) + "\', productCategory= \'" + rs.getString(6) + "\', sellingPrice= $" + rs.getFloat(8) + "]\n");
				pointer = 1;
			}
			if(pointer==1)
			{
				System.out.println("----------------------------------");
				System.out.println("1. See the Product Details");
				System.out.println("2. back");
				System.out.println("----------------------------------");
				CustomerDashboard customerDashboard = new CustomerDashboard();
				int choice = sc.nextInt();
				switch(choice)
				{
				case 1:
					System.out.println("----------------------------------");
					System.out.println("ENTER PRODUCT ID");
					System.out.println("----------------------------------");
					int pId = sc.nextInt();
					System.out.println("----------------------------------");
					pst = ProductsInformationDB.con.prepareStatement("Select * from products where productId=?");
					pst.setInt(1, pId);
					ResultSet result = pst.executeQuery();
					while(result.next())
					{
						System.out.println("\n--- -- --- " + result.getString(2) + " (" + result.getString(3)
						+ ") --- -- ---\n --- Description : " + result.getString(4) + " ---\n --- Highlights : " + result.getString(5)
						+ " ---\n --- Category : " + result.getString(6) + " --- \n --- Price : $" + result.getString(9) + " ---\n");
						System.out.println("----------------------------------");
						System.out.println("1. Add To Cart");
						System.out.println("2. Back");
						System.out.println("----------------------------------");
						int select = sc.nextInt();
						System.out.println("----------------------------------");
						switch(select)
						{
						case 1:
							registConn = CustomerRegistration.getConnection();
							pst = CustomerRegistration.con.prepareStatement("select customerId from Registration where customerEmailId=?");
							pst.setString(1,loginMail);
							ResultSet res = pst.executeQuery();
							while(res.next())
							{
								int custIdRecord = res.getInt(1);
								this.custId = custIdRecord;

							} 

							customerDashboard.addToCart(pId, custId);
							System.out.println("----------------------------------");
							break;
						case 2:
							break;
						default:
							System.out.println("invalid input");
							break;
						}
					}
					break;

				case 2:
					break;
				default:
					System.out.println("invalid input");
					break;
				}
				pointer=0;
			}
			else
			{
				System.out.println("Category doesn't exists");
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}




	}
	//----------END OF VIEW BY CATEGORY FOR CUSTOMER------------------

	//-------------------Total Amount Spend on Categories---------------------------
	@Override
	public void tSpendAmount() {

		System.out.println("Enter Category");
		String category = sc.next();
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select availableQuantity,buyingPrice from products where productCategory=?");
			pst.setString(1, category);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				tSpendCategory += rs.getInt(1)*rs.getInt(2);
			}
			System.out.println("--------------------------------------------");
			System.out.println("Total Amount Spend On "+category+" : "+ tSpendCategory);
			conn = ProductsInformationDB.getConnection();
			PreparedStatement ps = ProductsInformationDB.con.prepareStatement("select availableQuantity,buyingPrice from products");
			ResultSet rslt = ps.executeQuery();

			while(rslt.next())
			{
				tSpendAll += rslt.getInt(1)*rslt.getInt(2);
			}
			System.out.println("--------------------------------------------");
			System.out.println("Total Amount Spend On All Products : "+ tSpendAll);
			System.out.println("--------------------------------------------");
			System.out.println("Press any key to go back");
			String scan = sc.next();
			switch(scan)
			{
			case "dd":
				break;
			default:
				break;
			}
			tSpendCategory=0;
			tSpendAll=0;
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}

	}

	//-----------------------viewing all the products available in the store----------------
	@Override
	public void viewAllProducts()
	{
		try
		{
			conn = ProductsInformationDB.getConnection();
			PreparedStatement pst = ProductsInformationDB.con.prepareStatement("select * from products");
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				System.out.println("Product [productId=" + rs.getInt(1) + ", productName= " + rs.getString(2) + ", productText= \'" + rs.getString(3)
				+ "\', productDescription= \'" + rs.getString(4) + "\', productCategory= \'" + rs.getString(6) + "\', sellingPrice= $" + rs.getFloat(8) + "]\n");
			}
			System.out.println("--------------------------------------");
			String choice;
			System.out.println("Press any key to go Back");
			choice = sc.next();
			switch(choice)
			{
			case "dd": 
				break;
			default:
				break;
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}



}
