package com.hcl.gl.dao;

import java.sql.*;
import java.util.Random;
import java.util.Scanner;

import com.hcl.gl.daoInterface.CustomerDaoInterface;
import com.hcl.gl.jdbcConnection.CustomerRegistration;
import com.hcl.gl.logging.UserLog;
import com.hcl.gl.pojo.Customer;



public class CustomerDaoImp extends Thread implements CustomerDaoInterface {

	CustomerRegistration conn;
	PreparedStatement pst;
	int userExist;
	
	Scanner sc = new Scanner(System.in);
	Customer customer = new Customer();

	//----------------------------USING THREAD FOR CUSTOMER--------------------------
	public void run()
	{
		System.out.println("------WELCOME TO CUSTOMER PANEL------");
		System.out.println("--------------------------------------");
	}
	//--------------------------------END OF CUSTOMER THREAD--------------------------------
	
	//-------------------------------Customer Register Function----------------------------------------
	public void register()
	{
		Random random = new Random();
		int custId, supercoins, custPin;
		String custName, custEmail, custPassword;
		// ----------------------CUSTOMER INPUT---------------------------

		try
		{
			System.out.println("-------Registering New Customer-------");
			System.out.println("--------------------------------------");
			System.out.println("ENTER CUSTOMER NAME");
			custName = sc.next();
			System.out.println("ENTER EMAIL ID");
			custEmail = sc.next();
			System.out.println("Enter ADRESS PINCODE");
			custPin = sc.nextInt();
			System.out.println("ENTER PASSWORD");
			custPassword = sc.next();
			System.out.println("--------------------------------------");
			supercoins = 100;

			custId = random.nextInt(9999);
			customer.setCustomerId(custId);
			customer.setCustomerName(custName);
			customer.setCustomerEmailId(custEmail);
			customer.setCustomerPin(custPin);
			customer.setCustomerPassword(custPassword);
			customer.setSupercoins(supercoins);

			conn = CustomerRegistration.getConnection();
			PreparedStatement pst = CustomerRegistration.con.prepareStatement("insert into Registration values(?,?,?,?,?,?)");
			pst.setInt(1, custId);
			pst.setString(2, custName);
			pst.setString(3, custEmail);
			pst.setString(4, custPassword);
			pst.setInt(5, custPin);
			pst.setInt(6, supercoins);

			int resultSet = pst.executeUpdate();
			if(resultSet == 1)
			{
				UserLog.writeLog("Customer registered successfully");
			}
			else
			{
				System.out.println("customer could not be added");
			}
			
		}
		catch(SQLIntegrityConstraintViolationException ex)
		{
			System.out.println("Email Id already Registered with some other User!");
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}


	}

	//-------------------------------Customer Login Function---------------------------------------
	public void login()
	{

		String loginPass, loginMail;

		CustomerDaoImp customerImp = new CustomerDaoImp();
		
		//---------------------CALLING THREAD----------------
		customerImp.run();
		//------------------------------------------------
		System.out.println("ENTER EMAIL_ID");
		loginMail = sc.next();
		System.out.println("ENTER PASSWORD");
		loginPass = sc.next();
		System.out.println("--------------------------------------");

		try
		{
			conn = CustomerRegistration.getConnection();
			PreparedStatement pst = CustomerRegistration.con.prepareStatement("select * from Registration where customerEmailId=? AND customerPassword=?");
			pst.setString(1, loginMail);
			pst.setString(2, loginPass);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				userExist=1;
				UserLog.writeLog("logged in successfully");
				CustomerDashboard customerDashboard = new CustomerDashboard(loginMail);
				StoreInformationImp storeInformationImp = new StoreInformationImp(loginMail);
				int choose;
				System.out.println("You have been given 100 supercoins as welcome bonus");
				do
				{
					System.out.println("\n----------CUSTOMER DASHBOARD----------");
					System.out.println("--------------------------------------");
					System.out.println("1. View All Products");
					System.out.println("2. View products by Category");
					System.out.println("3. Cart");
					System.out.println("4. Account");
					System.out.println("0. Exit");
					System.out.println("--------------------------------------");

					choose = sc.nextInt();
					switch(choose)
					{
					case 1:
						customerDashboard.viewAllProduct();
						break;
					case 2:
						storeInformationImp.viewByCategoryForCustomer();
						break;
					case 3:
						customerDashboard.cart();
						break;
					case 4:
						customerDashboard.account();
						break;
					case 0:
						System.out.println("Exited");
						break;
					default:
						System.out.println("invalid input");
						break;
					}

				}
				while(choose!=0);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//----------------------Checking if User Exists or not----------------------
		if(userExist == 1)
		{
			userExist=0;
		}
		else
		{
			System.out.println("User doesn't Exist.");
		}
	}
}
