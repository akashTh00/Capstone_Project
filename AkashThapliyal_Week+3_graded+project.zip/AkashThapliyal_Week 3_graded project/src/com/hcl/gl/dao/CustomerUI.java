package com.hcl.gl.dao;
import java.util.*;


public class CustomerUI {

	public void customerinterface() throws Exception
	{

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int choice;
		CustomerDaoImp customerdaoimp = new CustomerDaoImp();
		do 
		{
			System.out.println("--------------------------------------");
			System.out.println("----------CUSTOMER INTERFACE---------");
			System.out.println("1. Register");
			System.out.println("2. login");
			System.out.println("0. Exit");
			System.out.println("--------------------------------------");
			System.out.println("SELECT AN OPTION");
			choice = sc.nextInt();
			switch(choice) 
			{
			case 1: 
				customerdaoimp.register();
				break;
			case 2:
				customerdaoimp.login();
				break;
			case 0:
				System.out.println("Exited.\n");
				break;
			default:
				break;
			}

		}while(choice != 0);
	}
}
