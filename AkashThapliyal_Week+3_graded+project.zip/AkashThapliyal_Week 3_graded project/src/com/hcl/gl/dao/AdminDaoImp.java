package com.hcl.gl.dao;

import java.util.Scanner;

import com.hcl.gl.Exception.NegativeExcepAdmin;
import com.hcl.gl.pojo.Admin;

//---------------------lambda expressions------------------------------------
@FunctionalInterface
interface listingProduct
{
	public void listProduct();
}

@FunctionalInterface
interface searchingProductById
{
	public void searchProductById();
}

@FunctionalInterface
interface searchingProductByName
{
	public void searchProductByName();
}

@FunctionalInterface
interface viewingProductByCategory
{
	public void viewProductByCategory();
}

@FunctionalInterface
interface totalSpendAmount
{
	public void totalSpend();
}

@FunctionalInterface
interface viewingProfitByCategory
{
	public void viewProfit();
}

@FunctionalInterface
interface viewingByIdName
{
	public void viewProduct();
}

@FunctionalInterface
interface viewingAllProducts
{
	public void viewingAll();
}
//---------------------------AdminDaoImp Class------------------------------------
public class AdminDaoImp extends Thread {

	//-------------------------------using THREAD for ADMIN-------------------------------
	public void run()
	{
		System.out.println("----------------------------------");
		System.out.println("------WELCOME TO ADMIN PANEL------");
		System.out.println("----------------------------------");
	}
	//----------------------------------END OF THREAD------------------------------
	public void adminPanel()
	{
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String adminName, password;

		Admin admin = new Admin();
		AdminDaoImp adminDao = new AdminDaoImp();
		//---------------------CALLING THREAD----------------
		adminDao.run();
		//---------------------------------------------
		System.out.println("ENTER LOGIN NAME");
		adminName = sc.next();
		System.out.println("ENTER PASSWORD");
		password = sc.next();
		System.out.println("----------------------------------");
		if(adminName.equalsIgnoreCase(admin.getAdminName()) && password.equalsIgnoreCase(admin.getPassword()))
		{
			try
			{
				int opt;
				StoreInformationImp productDaoImp = new StoreInformationImp();
				do 
				{
					System.out.println("--------------------------------------");
					System.out.println("----------ADMIN DASHBOARD-----------");
					System.out.println("--------------------------------------");
					System.out.println("1. List the products in to the Store");
					System.out.println("2. Search by product Id");
					System.out.println("3. View products by Category");
					System.out.println("4. View All Products");
					System.out.println("5. Total amount spend on products");
					System.out.println("0. Exit\n");
					System.out.println("--------------------------------------");
					System.out.println("Select any");
					System.out.println("--------------------------------------");
					opt = sc.nextInt();

					switch(opt)
					{
					case 1:
						listingProduct list = () -> {
							System.out.println("--------------------------------------");
							System.out.println("-----------Listing Product-----------");
							System.out.println("--------------------------------------");
							productDaoImp.listProduct();
						};
						list.listProduct();
						break;

					case 2:
						searchingProductById searchById = () -> {
							System.out.println("--------------------------------------");
							System.out.println("----------searching----------");
							System.out.println("--------------------------------------");
							productDaoImp.searchById();
						};
						searchById.searchProductById();
						break;

					case 3:
						viewingProductByCategory viewByCategory = () -> {
							System.out.println("--------------------------------------");
							System.out.println("----------viewing----------");
							System.out.println("--------------------------------------");
							productDaoImp.viewByCategory();
						};
						viewByCategory.viewProductByCategory();
						break;

					case 4:
						viewingAllProducts viewAll = () -> {
							System.out.println("--------------------------------------");
							System.out.println("----------viewing----------");
							System.out.println("--------------------------------------");
							productDaoImp.viewAllProducts();
						};
						viewAll.viewingAll();
						break;

					case 5:
						viewingProfitByCategory viewProfit = () -> {
							System.out.println("--------------------------------------");
							System.out.println("----------Calculating----------");
							System.out.println("--------------------------------------");
							productDaoImp.tSpendAmount();
						};
						viewProfit.viewProfit();
						break;

					case 0:
						break;
					default:
						System.out.println("invalid input");
						break;
					}

				}while(opt!=0);
				
				throw new NegativeExcepAdmin("");
			}
			catch(NegativeExcepAdmin e)
			{
				
			}
		}
		else
		{
			System.out.println("Failed to log you in.");
		}

	}
}
