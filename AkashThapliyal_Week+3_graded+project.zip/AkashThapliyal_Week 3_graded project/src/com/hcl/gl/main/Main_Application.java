package com.hcl.gl.main;


import com.hcl.gl.dao.AdminDaoImp;
import com.hcl.gl.dao.CustomerUI;
import java.util.*;
//---------------------------------MAIN --------------------------------------------------
public class Main_Application {

	public static void main(String[] args) throws Exception
	{

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		int option = 0;
		try
		{
			do {
				System.out.println("--------------------------------");
				System.out.println("MAY I KNOW IF YOU ARE:");
				System.out.println("1.\'ADMIN'");
				System.out.println("2.\'CUSTOMER'");
				System.out.println("--------------------------------");
				option = sc.nextInt();
				switch(option)
				{
				case 1:
					AdminDaoImp admindaoimp = new AdminDaoImp();
					admindaoimp.adminPanel();
					break;
				case 2:
					CustomerUI customerui = new CustomerUI();
					customerui.customerinterface();
					break;
				default:
					System.out.println("invalid input");
					break;
				}

			}
			while(option != 0);
		}

		catch(InputMismatchException ex)
		{
			System.out.println("ERROR: invalid input, Try Again!");
		}

	}
}
