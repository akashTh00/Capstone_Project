ADMIN :-
	[LOGIN NAME : PRINCY],
	[PASSWORD : PRINCY]
	
	
	
	
	(JDBC : Id - root , password - Aa2000@com)