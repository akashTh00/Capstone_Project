create database CustomerRegistration;

use CustomerRegistration;
create table Registration(customerId int not null unique PRIMARY KEY,
					  customerName varchar(40) not null,
                      customerEmailId varchar(50) not null unique,
                      customerPassword varchar(40) not null,
                      customerAdress varchar(60) not null,
                      supercoins int not null);
                      
select customerId from Registration;

select * from Registration;
drop table Registration;