create database ProductsInformationDB;
use ProductsInformationDB;

create table products(productId int not null unique PRIMARY KEY,
					  productName varchar(40) not null,
                      productText varchar(60) not null,
                      productDescription varchar(80) not null,
                      productHighlights varchar (120) not null,
                      productCategory varchar(40) not null,
                      availableQuantity int not null,
                      buyingPrice int not null,
                      sellingPrice float not null);
                      

insert into products values(4543, "Rice", "Rajhdhani (500g)", "For a Fitter, Healthier You!", "Easy doorstep","Grocery", 20, 100, 150 );
insert into products values(5434, "Flour", "Organic ragi flour(500 g)", "Easy Doorstep DeliverY","Good Quality Flour", "Grocery", 20, 50, 75);
insert into products values(7767, "Sports T-Shirt", "Get Sporty", "solid men round neck", "10 Days Return Policy", "Sports", 20, 1000, 1500);
insert into products values(7767, "Cricket Kit", "Ceat Bat", "COMBO BAT+BALL", "10 Days Return Policy", "Sports", 20, 2000, 3000);
insert into products values(7465, "Containers", "Grocery Container", "PACK of 18", "7 Days Return Policy", "HOME", 20, 100, 200);
insert into products values(7657, "Dinner Set", "WHITE, microwave safe", "PACK OF : 22", "7 Days Return Policy", "HOME", 20, 2000, 3000);
insert into products values(8767, "Samsung F76", "NIGHTSKY green", "#JUST HERE", "STORAGE: 64GB, 10 Days Return Policy", "MOBILE", 20, 10000, 15000);
insert into products values(4347, "remote controlled Helicopter", "multicolor", "Rechargeable batteries", "10 Days Return Policy", "Toys", 20, 2000, 3000);
insert into products values(2224, "Ensure Diabetes Care", "200g", "Scientific Formula To Help Manage Health", "10 Days Return Policy", "Nutrition", 20, 4000, 6000);
insert into products values(4533, "bOURN Vita", "500g", "strong bones, active brain", "Inner Strength Formula", "Nutrition", 20, 2000, 3000);

select * from products;          
