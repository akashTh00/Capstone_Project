create database CustomerCartRecords2;
use customerCartRecords2;

create table cart2(customerId int not null,
				  productId int not null,
                  status varchar(20) not null);
              
select * from cart2;


desc cart2;

drop table cart2;